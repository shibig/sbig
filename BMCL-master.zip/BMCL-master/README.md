BMCLV3
======

1.与[BMCLAPI](http://bmclapi.bangbang93.com)整合

2.重构大部分V2源码，使BMCL运行更快

3.添加插件功能

4.修正部分V2留下的bug