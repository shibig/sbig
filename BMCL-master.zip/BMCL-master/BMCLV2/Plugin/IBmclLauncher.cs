﻿namespace BMCLV2.Plugin
{
    public interface IBmclLauncher : IBmclPlugin
    {
        
    }
}