﻿namespace BMCLV2.Plugin
{
    public interface IBmclMirror : IBmclPlugin
    {
        
    }
}