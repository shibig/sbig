﻿using System.ComponentModel;
using BMCLV2.I18N;

namespace BMCLV2.Cfg
{
    public enum LaunchMode
    {
        Normal,
        Standalone
    }
}