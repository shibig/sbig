﻿namespace BMCLV2.Exceptions
{
    public class ProcessNotStartException : System.Exception
    {
         
    }
}