﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BMCLV2.Login
{
    public struct LoginInfo
    {
        public string UN;
        public string UID;
        public string SID;
        public bool Suc;
        public string Errinfo;
        public string OtherInfo;
        public string Client_identifier;
        public string OutInfo;
    }
}
